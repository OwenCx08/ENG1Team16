<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Eng1TileSet" tilewidth="32" tileheight="32" tilecount="81" columns="9">
 <image source="TileSheet.png" width="288" height="288"/>
</tileset>
