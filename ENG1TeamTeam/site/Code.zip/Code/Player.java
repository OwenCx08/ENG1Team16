public class Player extends Character{
    public Player(Board Board, String name, College College, int[] pos, int points, int plunder){
        super(Board, name, College, pos, points, plunder);
    }
}