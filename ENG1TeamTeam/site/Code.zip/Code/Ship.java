public class Ship extends Character{
    public Ship(Board Board, String name, College College, int[] pos, int points, int plunder){
        super(Board, name, College, pos, points, plunder);
    }
}