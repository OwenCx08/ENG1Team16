public class College extends GameObject{
    public College(Board Board, String name, int[] pos, int points, int plunder){
        super(Board, name, pos, points, plunder);
    }
}