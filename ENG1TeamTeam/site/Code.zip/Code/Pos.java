public class Pos{
    public int x;
    public int y;
}